class WomStrings():

    #### strings for properties

    # for the propertyGroup
    wom_pg                      = 'wom'
    wom_id                      = 'wom_id'
    wom_type                    = 'wom_type'
    wom_driven                  = 'wom_driven'
    wom_forward_axis            = 'forward_axis'
    wom_position_old            = 'position_old'
    wom_show_tracker            = 'show_tracker'

    test_prop                   = 'test_prop'

    # for regular properties
    wom_radius                  = 'wom_radius' 
    wom_rotation_power          = 'wom_auto_rotation_power' 
    wom_auto_rotation           = 'wom_auto_rotation'
    wom_id_ui                   = 'wom_id_ui'

    # pointers
    wom_ground_tracker            = 'wom_ground_tracker'

    #### strings for trackers/controllers
    # wom_tracker_axis            = 'wom_data'
    # wom_tracker_ground          = 'ground'
    # wom_tracker_helper          = 'helper'
    # wom_tracker_rotation        = 'rotation'
    # wom_auto_parent             = 'auto_parent'
    # wom_tracker_main            = wom_tracker_ground 

    #### types for identifying all wom objects
    type_target                 = 'target'
    type_ground                 = 'ground'
    type_rotation               = 'rotation'
    type_collection             = 'collection'
    type_main_collection        = 'main_collection'
    type_axis                   = 'axis'
    type_auto_parent            = 'auto_parent'

    # strings for collections
    wom_collection_main_name    = 'Wheel-O-Matic'
    wom_collection_main_id      = 'main_collection'
    wom_collection_affix        = 'wom_collection'

    #### UI hint strings
    desc_auto_rot           =   'Auto rotation of the wheel (in radians). DO NOT EDIT! Will break the wheel logic' 
    desc_auto_rot_power     =   'Strength of the auto rotation. 1 is default. 0 is no rotation. Negative values reverse rotation. Type in values to go beyond limits.'
    desc_radius             =   'Radius of the wheel, adjust as needed. Enable \'Show Tracker\' above to visualize.'
    desc_show_tracker       =   'Show the wheel tracker. If it\'s not showing, make sure it\'s collection is not hidden or disabled.'

    #### UI names
    name_radius             =   'Radius'
    name_auto_rot_power     =   'Rotation Power'
    name_show_tracker       =   'Show Tracker'
    name_auto_rotation      =   'Auto Rotation'