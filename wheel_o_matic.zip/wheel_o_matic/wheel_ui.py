import bpy
# from math import degrees
from .wheel_strings import WomStrings as ws
from .wheel_utilities import WomUtils
wu = WomUtils()


# Property group for ui elements 
class Wheel_UI_Properties(bpy.types.PropertyGroup):

    #### Tool Hints
    desc_apply_trasforms    =   'Apply rotation and scale of the wheel geo to clean the transforms before setup'
    desc_auto_rot           =   'Auto rotation of the wheel in degrees' 
    desc_auto_rot_power     =   'Strength of the auto rotation. 1 is default. 0 is no rotation. Negative values reverse rotation.'
    desc_show_tracker       =   'Show the wheel tracker automatically on creation.'
    desc_override_defaults  =   'Override the default settings for automation'
    desc_radius             =   'Radius of the wheel. Auto calculated on setup, adjust as needed'
    desc_show_axes          =   'Display local rotation axes for the bones'
    desc_wheel_obj          =   'Geo of the wheel. Select the outermost geo (like the tire) if wheel is in multiple pieces'
    
  

    #### Getters/setters for ui elements

    # def get_auto_rot_power(self):
    #     val = 0
    #     if wu.get_wom_id_for_active_object_or_pose_bone():
    #         obj = bpy.context.object
    #         if obj.get('auto_rot_power'):
    #             val = obj['auto_rot_power']
    #     return val

    # def set_auto_rot_power(self,value):
    #     obj = bpy.context.object
    #     if obj:
    #         obj['auto_rot_power'] = value


    # def get_auto_rotation(self):
    #     val = 0
    #     # if bpy.context.active_object.get(ws.wom_driven):
    #     val = 0
    #     # if wu.get_wom_id_for_active_object_or_pose_bone():
    #     obj = bpy.context.object
    #     if obj.get('auto_rotation'):
    #         val = obj['auto_rotation']
    #     return val
    

    # def get_radius(self):
    #     val = 0.001
    #     # if wu.get_wom_id_for_active_object_or_pose_bone():
    #     obj = bpy.context.object
    #     if obj.get('radius'):
    #         val = obj['radius']
    #     return val


    # def set_radius(self,value):
    #     if value < 0.001:
    #         value = 0.001
    #     obj = bpy.context.object
    #     if obj:
    #         obj['radius'] = value


    # def get_show_main_tracker(self):
    #     if wu.get_wom_id_for_active_object_or_pose_bone():
    #         tracker = self.get_wom_tracker(ws.wom_tracker_ground)
    #         if tracker:
    #             value = tracker.hide_get()
    #             value2 = tracker.hide_viewport

    #             if value == value2:
    #                 value = not value
    #             return value
    #     return False
    
    # def show_main_tracker(self,value):
    #     tracker = self.get_wom_tracker(ws.wom_tracker_ground)
    #     if tracker:
    #         value = not value
    #         tracker.hide_set(value)
    #         tracker.hide_viewport = value


    # def get_wom_tracker(self,tracker_type):
    #     tracker = None
    #     wom_id = wu.get_wom_id_for_active_object_or_pose_bone()
    #     if wom_id:
    #         tracker_lookup = wu.get_connected_wom_controller_of_type(wom_id,tracker_type)
    #         if tracker_lookup:
    #             tracker = tracker_lookup
    #     return tracker
    
    # def get_some_prop(self):
    #     return bpy.context.object['some_prop']
        
    # def set_some_prop(self,val):
    #     bpy.context.object['some_prop']= val

    # filtered poll result for when picking mesh for bone setup
    def valid_wheel_object(self,object):
        """ limit dropdown to current scene, and limit to mesh objects"""
        for scene in object.users_scene:
            if scene.name == bpy.context.scene.name:
                if object.type == 'MESH':
                    return object

    

    #### UI for Setup panel
    
    b_apply_trasforms       :   bpy.props.BoolProperty (name = 'Clean Geo Transforms', default=False, description = desc_apply_trasforms)
    b_override_defaults     :   bpy.props.BoolProperty (name = 'Override Defaults', description = desc_override_defaults)
    b_show_tracker          :   bpy.props.BoolProperty (name = 'Show Tracker On Create', default=True, description = desc_show_tracker)
    p_wheel_obj             :   bpy.props.PointerProperty(name = '', type=bpy.types.Object,poll=valid_wheel_object, description = desc_wheel_obj)

    world_forward_axis      :   bpy.props.EnumProperty(
                                    name= '',
                                    description = "World forward axis of the wheel",
                                    items=  [('auto','Auto','Automatically detect forward axis (default)','',0),
                                            ('x','X','Wheel rolls forward on the world X axis','',1),
                                            ('y','Y','Wheel rolls forward  on the world Y axis','',2)],
                                    default = 'auto'
                                )


    #### UI for Adjust panel

    # b_show_tracker          :   bpy.props.BoolProperty (name = 'Show Wheel Tracker', description = desc_main_tracker,
    #                             get=get_show_main_tracker, set=show_main_tracker)
    
    # f_auto_rot_power        :   bpy.props.FloatProperty (name = 'Rotate Strength', description = desc_auto_rot_power,
    #                             get=get_auto_rot_power, set=set_auto_rot_power)
    
    # f_auto_rotation         :   bpy.props.FloatProperty (name = 'Auto Rotation Total', description = desc_auto_rot,
    #                             get=get_auto_rotation)
    
    # f_radius                :   bpy.props.FloatProperty (name = 'Wheel Radius', description = desc_radius,
    #                             get=get_radius, set=set_radius)



    

class VIEW3D_PT_wheel_o_matic(bpy.types.Panel):
    """panel for Wheel O Matic"""
    bl_label = "Wheel-O-Matic"
    bl_category = 'Item'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 10

    # only draw if mode and selection is correct
    @classmethod
    def poll(cls, context):
        allow_draw_result = allow_draw(context)
        return allow_draw_result

    # draw panel
    def draw(self, context):
        pass

class VIEW3D_PT_wheel_o_matic_automate(bpy.types.Panel):
    """Automate panel for Wheel-O-Matic"""
    bl_label = "Create"
    bl_category = 'Item'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_parent_id = 'VIEW3D_PT_wheel_o_matic'

    def draw(self, context):
        w_ui = context.scene.wheel_o_matic
        layout = self.layout
        col = layout.column()


        # when in object mode
        if bpy.context.mode == 'OBJECT':
            valid_selection = automate_panel_logic_geo()
            col.label(text='For Selected Wheel(s)')
            draw_override_defaults(col,w_ui,geo_setup = True)
            automate_row = col.row()
            automate_row.operator('object.wom_wheel_setup_mesh', text='Automate')
            if not valid_selection:
                automate_row.enabled=False


        # when in pose mode
        if bpy.context.mode == 'POSE':
            col.label(text='Selected Bone:')
            bone_text,valid_bone_selection = automate_panel_logic_bones()
            col2 = col.column()
            c_box = centered_box(col2)
            c_box.label(text=f'{bone_text}')

            col2.label(text= 'Reference Wheel Geo:')
            col2.prop(w_ui,'p_wheel_obj',text = '')
            col2.separator()
            col2.enabled = valid_bone_selection

            col3 = col.column()
            draw_override_defaults(col3,w_ui,geo_setup=False)
            col3.operator('object.wom_wheel_setup_bone', text='Automate')
            if not valid_bone_selection or not w_ui.p_wheel_obj:
                col3.enabled = False

        col.separator()


class VIEW3D_PT_wheel_o_matic_adjust(bpy.types.Panel):
    """Adjust panel for Wheel O Matic"""
    bl_label = "Adjust"
    bl_category = 'Item'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_parent_id = 'VIEW3D_PT_wheel_o_matic'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        w_ui = context.scene.wheel_o_matic
        obj = bpy.context.object
        if obj:
            if obj.type == 'ARMATURE':
                bone = bpy.context.active_pose_bone
                if bone:
                    obj = bone
        layout = self.layout
        allow_adjust, selection_text = adjust_panel_logic()
        col = layout.column()
        col.enabled = allow_adjust
        c_box = centered_box(col)
        c_box.label(text=selection_text)
        col.prop(obj.wom,ws.wom_show_tracker)
        grid = col.grid_flow(columns=1, align=True)
        grid.prop(obj, ws.wom_rotation_power)
        grid.prop(obj, ws.wom_radius)
        grid.prop(obj.wom, ws.wom_id_ui)

        ### test property with buttom
        # row = grid.row()
        # split = row.split(factor=0.75)
        # split.prop(obj.wom,ws.test_prop)
        # split.operator('object.wom_key_test', text='Key')
        # col.separator()


class VIEW3D_PT_wheel_o_matic_clean(bpy.types.Panel):
    """Clean panel for Wheel O Matic"""
    bl_label = "Clean"
    bl_category = 'Item'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_parent_id = 'VIEW3D_PT_wheel_o_matic'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        box = col.box()
        box.label(text='For Selected Wheels/Bones:')
        col2 = box.column()
        col2.operator('object.wom_wheel_clear_rotation', text='Clear Auto Rotation')
        col2.operator('object.wom_wheel_remove_automation', text='Remove Automation')
        allow_adjust = clear_panel_logic()
        col2.enabled = allow_adjust
        col.separator()
        col.operator('object.wom_remove_stray_data',text='Remove Stray Data')



def allow_draw(context):
    valid = False
    mode = bpy.context.mode
    if mode == 'OBJECT':
        valid = True
    if mode == 'POSE':
        valid = True
    if context.object is None:
        valid = False
    return valid

def draw_override_defaults(col,w_ui,geo_setup = False):
    col.prop(w_ui,'b_override_defaults')
    if w_ui.b_override_defaults:
        box = col.box()
        row = box.row()
        row.label(text='Forward Axis:')
        row.prop(w_ui,'world_forward_axis', expand=False)
        box_col = box.column()
        box_col.prop(w_ui,'b_show_tracker')
        if geo_setup:
            box_col.prop(w_ui,'b_apply_trasforms')

def centered_box(ui_parent):
        box = ui_parent.box()
        col = box.column()
        row = col.row()
        row.alignment = 'CENTER'
        return row

def automate_panel_logic_geo():
    selection = bpy.context.selected_objects
    if not selection:
        return False
    else:
        for sel in selection:
            if not sel.mode == 'OBJECT':
                return False
            if not sel.type == 'MESH':
                return False
    return True

def automate_panel_logic_bones():
    pose_bones = bpy.context.selected_pose_bones
    if len(pose_bones) == 0:
        return 'None Selected',False
    if len(pose_bones) == 1:
        return pose_bones[0].name,True
    else:
        return 'Too Many Bones Selected',False

def adjust_panel_logic():

    no_selection = 'Nothing Selected'
    multiple_selected = 'Multiple Selected'
    no_wom_data = 'Not Automated'

    if bpy.context.mode == 'POSE':
        active_obj = bpy.context.active_pose_bone
        selected = bpy.context.selected_pose_bones

    if bpy.context.mode == 'OBJECT':
        selected = bpy.context.selected_objects
        active_obj = bpy.context.object

    count = len(selected)
    if count == 0:
        return False, no_selection
    elif count > 1:
        return False, multiple_selected
    elif count == 1:
        for sel in selected:
            if sel == active_obj:
                wom_driven = active_obj.wom.get(ws.wom_driven)
                if wom_driven:
                    return True, sel.name
        return False, no_wom_data

    else:
        return False, no_selection


def clear_panel_logic():
    wu = WomUtils()
    selected = bpy.context.selected_objects
    for sel in selected:
        if wu.is_wom_driven(sel):
            return True
    return False



ui_elements = [Wheel_UI_Properties,VIEW3D_PT_wheel_o_matic,VIEW3D_PT_wheel_o_matic_automate,VIEW3D_PT_wheel_o_matic_adjust,VIEW3D_PT_wheel_o_matic_clean]