


import bpy
import mathutils
from .wheel_strings import WomStrings as ws


#### Get/set/update for properties shown in ui
def update_radius(self,context):
    if self.wom:
        tracker = self.wom.get(ws.wom_ground_tracker)
        if tracker:
            val = getattr(self,ws.wom_radius)
            tracker.delta_location[2] = -val


def get_wom_id(self):
    return self[ws.wom_id]


def get_wom_type(self):
    return self[ws.wom_type]

# def get_auto_rotation(self):
#     # return self.get(ws.wom_auto_rotation)
#     return self[ws.wom_auto_rotation]

# def set_auto_rotation(self,value):
#     # self[ws.wom_auto_rotation] = value
#     self[ws.wom_auto_rotation] = self[ws.wom_auto_rotation]

# def update_auto_rotation(self,context):
#     self[ws.wom_auto_rotation] = self[ws.wom_auto_rotation]
# def get_forward_axis(self):
#     return self[ws.wom_forward_axis]

# def get_position_old(self):
#     return self[ws.wom_position_old]

#### User facing adjustable properties that are not part of the hidden Wheel-O-Matic property group
def register_user_facing_properties():
    # wom auto rotation
    setattr(bpy.types.Object,ws.wom_auto_rotation,bpy.props.FloatProperty(name=ws.name_auto_rotation,default = 0.0,description=ws.desc_auto_rot))
    setattr(bpy.types.PoseBone,ws.wom_auto_rotation,bpy.props.FloatProperty(name=ws.name_auto_rotation,default = 0.0,description=ws.desc_auto_rot))

    # wom auto rotation power
    setattr(bpy.types.Object,ws.wom_rotation_power,bpy.props.FloatProperty(name=ws.name_auto_rot_power,default = 1,soft_min=-5,soft_max=5,description=ws.desc_auto_rot_power))
    setattr(bpy.types.PoseBone,ws.wom_rotation_power,bpy.props.FloatProperty(name=ws.name_auto_rot_power,default = 1,soft_min=-5,soft_max=5,description=ws.desc_auto_rot_power))
    
    # wom radius
    setattr(bpy.types.PoseBone,ws.wom_radius,bpy.props.FloatProperty(name=ws.name_radius,min=0.001,default=1,description=ws.desc_radius,update=update_radius))
    setattr(bpy.types.Object,ws.wom_radius,bpy.props.FloatProperty(name=ws.name_radius,min=0.001,default=1,description=ws.desc_radius,update=update_radius))


#### wheel-O-matic object property group ####
class Wheel_Object_Properties(bpy.types.PropertyGroup):

    def get_show_tracker(self):
        if self.get(ws.wom_show_tracker):
            return self[ws.wom_show_tracker]
        else:
            return False

    def set_show_tracker(self,value):
        tracker = self.get(ws.wom_ground_tracker)
        if tracker:
            inverse_val = not(value)
            tracker.hide_set(inverse_val)
            tracker.hide_viewport = inverse_val
            # also unhide the collection just in case
            if value == True:
                # collections = Collections()
                col = tracker.users_collection[0]
                col.hide_viewport = False
                # collections.force_show_collection(col)

        self[ws.wom_show_tracker] = value

    def get_wom_id_ui(self):
        if self.get(ws.wom_id):
            return self[ws.wom_id]
        return ''

        

    # user adjustable/forward facing
    show_tracker            :   bpy.props.BoolProperty(name=ws.name_show_tracker,default=False,description = ws.desc_show_tracker, get=get_show_tracker, set = set_show_tracker)
    # test_prop               :   bpy.props.FloatProperty(name='test prop', default=1.0)
    # show_tracker            :   bpy.props.BoolProperty(name=ws.name_show_tracker,description = ws.desc_show_tracker)


    # internal
    forward_axis            :   bpy.props.StringProperty()
    position_old            :   bpy.props.FloatVectorProperty()
    wom_id                  :   bpy.props.StringProperty()
    wom_type                :   bpy.props.StringProperty()
    wom_id_ui               :   bpy.props.StringProperty(name='',get=get_wom_id_ui)
    wom_driven              :   bpy.props.BoolProperty()
    wom_ground_tracker      :   bpy.props.PointerProperty(type=bpy.types.Object)
    # wom_target_obj          :   bpy.props.PointerProperty(type=bpy.types.Object)
    # wom_target_pb           :   bpy.props.PointerProperty(type=bpy.types.PoseBone)
    test_prop               : bpy.props.FloatProperty()




#### Operator Classes ####
    
# setup meshes
class OBJECT_OT_wom_setup_mesh(bpy.types.Operator):

    """Automate rotation on the selected wheels"""
    bl_idname = 'object.wom_wheel_setup_mesh'
    bl_label = 'Wheel-O-Matic: mesh setup'
    bl_options = {"REGISTER", "UNDO"}

    
    def execute(self,context):
        wheel_setup = WheelOperators()
        wheel_setup.mesh_setup()
        return {'FINISHED'}


# setup bones
class OBJECT_OT_wom_setup_bone(bpy.types.Operator):

    """Automate rotation of selected bone"""
    bl_idname = 'object.wom_wheel_setup_bone'
    bl_label = 'Wheel-O-Matic: bone setup'
    bl_options = {"REGISTER", "UNDO"}

    
    def execute(self,context):
        wheel_setup = WheelOperators()
        wheel_setup.bone_setup()
        return {'FINISHED'}


# zero out auto rotation
class OBJECT_OT_wom_clear_rotation(bpy.types.Operator):
    """Reset automated wheel rotation to zero"""
    bl_idname = 'object.wom_wheel_clear_rotation'
    bl_label = 'Wheel-O-Matic: clear automated rotation'
    bl_options = {"REGISTER", "UNDO"}

    def execute(self,context):
        # reset auto rotation
        wheel_setup = WheelOperators()
        wheel_setup.clear_rotation()
        return {'FINISHED'}


# remove automation
class OBJECT_OT_wom_remove_automation(bpy.types.Operator):
    """Removes any wheel-O-matic automation/controls from the selected items"""
    bl_idname = 'object.wom_wheel_remove_automation'
    bl_label = 'Wheel-O-Matic: Remove automation'
    bl_options = {"REGISTER", "UNDO"}

    
    def execute(self,context):
        wheel_setup = WheelOperators()
        wheel_setup.remove_automation_bulk()
        return {'FINISHED'}
    
    def invoke(self, context, event):
        title_txt = 'Remove autmation for the selected wheels/bones?'
        button_txt = 'Remove'
        try:
            return context.window_manager.invoke_props_dialog(self,confirm_text=button_txt,title=title_txt)
        except:
            return context.window_manager.invoke_props_dialog(self)

# remove stray wom data (stray data occurs when a driven wheel is deleted)
class OBJECT_OT_wom_remove_stray_data(bpy.types.Operator):
    """ Removes any Wheel-O-Matic objects/collections that no longer have a target wheel/bone to automate"""
    bl_idname = 'object.wom_remove_stray_data'
    bl_label = 'Wheel-O-Matic: Remove stray data'
    bl_options = {"REGISTER", "UNDO"}

    def execute(self,context):
        wu = WomUtils()
        wu.remove_stray_wom_data_from_scene()
        return {'FINISHED'}
    
    def invoke(self, context, event):
        title_txt = 'Remove stray Wheel-O-Matic data from the scene?'
        button_txt = 'Remove'
        try:
            return context.window_manager.invoke_props_dialog(self,confirm_text=button_txt,title=title_txt)
        except:
            return context.window_manager.invoke_props_dialog(self)


#### Class that holds the logic the operators point to ####
    
class WheelOperators(object):

    def __init__(self):
        self.w_ui = bpy.context.scene.wheel_o_matic


        # settings
        self.forward_axis = 'auto'
        self.clean_transforms = False

        if self.w_ui.b_override_defaults:
            self.forward_axis = self.w_ui.world_forward_axis
            self.clean_transforms = self.w_ui.b_apply_trasforms

      
    def mesh_setup(self):
        self.create_global_wheel_logic()

        wheels = []
        sel = bpy.context.selected_objects
        for asset in sel:
            if asset.type == 'MESH':
                wheels.append(asset)



        for wheel in wheels:

            # remove old automation if any
            if wheel.wom.get(ws.wom_id):
                self.remove_wom_control(wheel)

            # apply rotation and scale to get clean transforms on wheel geo
            if self.clean_transforms:
                bpy.ops.object.select_all(action='DESELECT')
                bpy.data.objects[wheel.name].select_set(True)
                bpy.context.view_layer.objects.active = wheel
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)


            # set unique wom id
            wu = WomUtils()
            wom_id = wu.set_wom_id(wheel)

            # create collection
            collection_utils = Collections()
            collection = collection_utils.create_collection(f'{wheel.name}.{ws.wom_collection_affix}',wom_id)
            

            # get wheel geo information
            wheel_geo_info = WheelGeoInfo(wheel,self.forward_axis)


            # create controllers for wheel
            wom_target = WomTargetData(wheel_geo_info,wheel,wheel_geo_info.rotation_axis,wheel_geo_info.matrix_world,collection,wom_id)
            trackers = Trackers(wom_target)
            trackers.create_all_trackers()

            # if no parent, see if there's a child of constraint
            wheel_parent = wheel.parent
            if not wheel_parent:
                wheel_constraints = wheel.constraints
                for constraint in wheel_constraints:
                    if constraint.type == 'CHILD_OF':
                        wheel_parent = constraint.target




            # add rotation constraint to wheel geo
            connection_utils = ConnectionUtils()
            constraint = connection_utils.constraint_final_rotation(wheel,trackers.rotation_tracker,wheel_geo_info.rotation_axis,is_bone=False)
            if wheel_geo_info.invert_rotation:
                setattr(constraint,f'invert_{wheel_geo_info.rotation_axis}', True)


            # show the tracker if set to do so
            if self.w_ui.b_show_tracker == True:
                trackers.ground_tracker.hide_set(False)
                trackers.ground_tracker.hide_viewport = False
                wheel.wom.show_tracker = True



            # constrain trackers to wheel to 'parent' if it exists (could be actual parent, or CHILD_OF constraint)
            if wheel_parent:
                connection_utils.constraint_child_of(trackers.axis_tracker,wheel_parent)


            # otherwise auto create a parent and connect it all to that
            else:
                parent_utils = ParentUtils()
                auto_parent = parent_utils.create_auto_parent_geo(wheel_geo_info,wom_id)
                connection_utils.constraint_child_of(wheel,auto_parent)
                connection_utils.constraint_child_of(trackers.axis_tracker,auto_parent)
                collection_utils.move_to_collection(auto_parent,collection)
                # select the controller to finalize
                bpy.ops.object.select_all(action='DESELECT')
                bpy.context.view_layer.objects.active = auto_parent
                bpy.data.objects[auto_parent.name].select_set(True)
                auto_parent.select_set(True)

            

        # set forward axis back to auto
        self.w_ui.world_forward_axis = 'auto'
        # clear initial rotation
        # bpy.app.timers.register(self.clear_rotation, first_interval=.001)


    def bone_setup(self):

        self.create_global_wheel_logic()

        # get wheel info
        wheel = self.w_ui.p_wheel_obj
        if not wheel:
            return
        else:
            wheel_info = WheelGeoInfo(wheel,self.forward_axis)

        # get selected pose bone
        selected_bone = bpy.context.active_pose_bone

        # get armature
        armature = None
        selected = bpy.context.selected_objects
        for sel in selected:
            if sel.type == 'ARMATURE':
                armature = sel
        

        if not armature or not selected_bone:
            return
        
        # remove any old automation data
        if selected_bone.wom.get(ws.wom_id):
            self.remove_wom_control(selected_bone)

                
        # get local rotation and invert rotation info
        wom_utils = WomUtils()
        local_rotation_axis, invert_rotation = wom_utils.get_local_rotation_axis_bone(wheel_info,selected_bone,armature)
        
        
        ### get world matrix of bone
        bone_matrix_world = selected_bone.id_data.matrix_world @ selected_bone.matrix

        ### setup wom_id data
        wom_id = wom_utils.set_wom_id(selected_bone,True)

        # create collection
        collection_utils = Collections()
        collection = collection_utils.create_collection(f'{selected_bone.name}.{ws.wom_collection_affix}',wom_id)

        # create trackers
        wom_target = WomTargetData(wheel_info,selected_bone,local_rotation_axis,bone_matrix_world,collection,wom_id,armature)
        trackers = Trackers(wom_target)
        trackers.create_all_trackers()

        # connect trackers to parent of selected bone. If no parent, follow the armature
        connection_utils = ConnectionUtils()
        parent = selected_bone.parent
        if parent:
            connection_utils.constraint_child_of_bone(trackers.axis_tracker,armature,parent)
        else:
            connection_utils.constraint_child_of(trackers.axis_tracker,armature)


        # Hook up the final rotation connection
        constraint = connection_utils.constraint_final_rotation(selected_bone,trackers.rotation_tracker,local_rotation_axis)
        if invert_rotation:
            setattr(constraint,f'invert_{local_rotation_axis}', True)
        # constraint_pointer = constraint.as_pointer() TODO use a pointer as well for a third way to find this constraint when it needs to be removed

        # show the tracker if set to do so
        if self.w_ui.b_show_tracker == True:
            trackers.ground_tracker.hide_set(False)
            trackers.ground_tracker.hide_viewport = False
            selected_bone.wom.show_tracker = True


        # clean up UI
        self.w_ui['p_wheel_obj'] = None
        self.w_ui.world_forward_axis = 'auto'


    def create_global_wheel_logic(self):
        text_name = 'wheel_logic'
        existing_text = bpy.data.texts.get(text_name)
        if not existing_text:
            new_text = bpy.data.texts.new(text_name)
            text_body = self.get_global_wheel_logic_string()
            new_text.write(text_body)
            new_text.use_module = True
            # execute the wheel logic for the first time
            bufferName = text_name
            wheel_logic = bpy.data.texts[bufferName].as_string()
            exec(wheel_logic)


    def get_global_wheel_logic_string(self):
        output = """import bpy
import mathutils
import math
def wheel_logic(self,mtx):
    current_pos = mtx.translation
    if self.id_data.type == 'ARMATURE':
        obj = bpy.data.objects[self.id_data.name].pose.bones[self.name]
    else:
        obj = bpy.data.objects[self.id_data.name]
    previous_pos =  mathutils.Vector(obj.wom.position_old)
    forward = mathutils.Vector((mtx[0][0], mtx[1][0], mtx[2][0]))
    if obj.wom.forward_axis == 'y':
        forward = mathutils.Vector((-mtx[0][1], -mtx[1][1], -mtx[2][1]))
    forward_mag = forward.magnitude
    forward = forward.normalized()
    change = mathutils.Vector(current_pos - previous_pos)
    traveled = (change.magnitude)
    change_direction = change.normalized()
    dot_scalar = change_direction.dot(forward)
    radius = obj.wom_radius
    obj.wom.position_old = current_pos
    distance = (traveled*dot_scalar*obj.wom_auto_rotation_power)
    radians = distance/(radius*forward_mag) + obj.wom_auto_rotation
    # obj.wom_auto_rotation = radians
    obj.wom_auto_rotation = radians
    return radians
bpy.app.driver_namespace['wheel_logic'] = wheel_logic"""
        return output


    def clear_rotation(self):

        for item in bpy.context.selected_objects:
            if item.type == 'MESH':
                if item.get(ws.wom_auto_rotation):
                    setattr(item,ws.wom_auto_rotation,0.0)

            elif item.type == 'ARMATURE':
                bone = bpy.context.active_pose_bone
                if bone:
                    if bone.get(ws.wom_auto_rotation):
                        setattr(bone,ws.wom_auto_rotation,0.0)
        current_scene = bpy.context.scene.name
        current_frame = bpy.data.scenes[current_scene].frame_current
        bpy.data.scenes[current_scene].frame_set(current_frame)

        #### these don't work to update
        # bpy.context.view_layer.update() 
        # for area in bpy.context.window.screen.areas:
        #     if area.type == 'VIEW_3D':
        #         area.tag_redraw()
        # bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)


    def remove_automation_bulk(self):
        wheel_setup = WheelOperators()
        selection = bpy.context.selected_objects
        objects_to_clean = []
        for sel in selection:
            if sel.type == 'ARMATURE':
                bones = bpy.context.selected_pose_bones
                if bones:
                    for b in bones:
                        objects_to_clean.append(b)

            elif sel.type == 'MESH':
                objects_to_clean.append(sel)

        for obj in objects_to_clean:
            if obj.wom.get(ws.wom_id):
                wheel_setup.remove_wom_control(obj) 


    def remove_wom_control(self,wheel_obj):
        all_scene_wom_objects = wu.get_scene_wom_objects()
        objects_to_remove = []
        has_wom_parent = []
        wheel_obj_id = wheel_obj.wom.get(ws.wom_id)

        wom_collection = collections.get_collection_by_id(wheel_obj_id)
        # if wom_collection:
        #     related_wom_objects = collections.get_wom_objects_in_collection(wom_collection)
        #     objects_to_remove += related_wom_objects

        # delete wheel o matic constraints
        remove_consts = []
        constraints = wheel_obj.constraints
        if constraints:
            for const in constraints:
                if hasattr(const,'target'):
                    target = const.target
                    if target:
                        if target.wom.get(ws.wom_id):
                            remove_consts.append(const)
                    elif 'Wheel-O-Matic' in const.name:
                        remove_consts.append(const)
        for const in remove_consts:
            wheel_obj.constraints.remove(const)



        #### remove wom driver   
        id_data = wheel_obj.id_data

        # remove driver for armature
        if id_data.type == 'ARMATURE':
            armature = id_data
            drivers = armature.animation_data.drivers
            for driver in drivers: 
                if 'wheel_logic' in driver.driver.expression:
                    data_path = driver.data_path
                    driven_bone_name = data_path.split('"')[1]
                    if wheel_obj.name == driven_bone_name:
                        armature.driver_remove(driver.data_path, -1)

        # remove wom driver for mesh
        else:
            drivers = wheel_obj.animation_data.drivers
            for driver in drivers: 
                if 'wheel_logic' in driver.driver.expression:
                    wheel_obj.driver_remove(driver.data_path, -1)


        # remove top level properties
        properties = [ws.wom_auto_rotation,ws.wom_radius,ws.wom_rotation_power]
        for prop in properties:
            value = wheel_obj.get(prop)
            if value is not None:
                del wheel_obj[prop] 
            
        # clear properties in wom property group
        pg_properties = [ws.wom_id,ws.wom_driven,ws.wom_show_tracker,ws.wom_type]
        for pg_prop in pg_properties:
            pg_value = wheel_obj.wom.get(pg_prop)
            if pg_value is not None:
                del wheel_obj.wom[pg_prop] 

            


        # delete objects with matching wom id if it's not the object itself, and don't delete any targets(in case someone duplicated a wheel)
        for item in all_scene_wom_objects:
            item_wom_id = item.wom.get(ws.wom_id)
            if item_wom_id == wheel_obj_id:
                if not item == wheel_obj:
                    item_type = item.wom.get(ws.wom_type)
                    if not item_type == ws.type_target:
                        bpy.data.objects.remove(item, do_unlink=True)


        # safely remove the collection by moving any left over items out of it
        collections.remove_collection(wom_collection)


#### Helper/utility classes for wheel operators
class Trackers():

    def __init__(self,wom_target):
        self.wom_target = wom_target
        self.axis_tracker = None
        self.ground_tracker = None
        self.rotation_tracker = None
        self.helper_tracker = None
        self.all_trackers = []

        # turn this to false when debugging to not lock/hide up all the controls
        self.lock = True


        self.collections        = Collections()
        self.connection_utils   = ConnectionUtils()
        self.wom_utils          = WomUtils()


    def create_all_trackers(self):
        self.create_axis_tracker()
        self.create_ground_tracker()
        self.create_rotation_tracker()
        self.set_tracker_hierarchy()
        self.set_tracker_locations()
        self.apply_target_logic()
        self.apply_rotation_tracker_logic()
        self.move_trackers_to_collections()
        self.lock_everything()


    def create_axis_tracker(self):
        self.axis_tracker = self.create_tracker(ws.type_axis)
        self.all_trackers.append(self.axis_tracker)

    def create_ground_tracker(self):
        self.ground_tracker = self.create_tracker(ws.type_ground,draw=True)
        self.all_trackers.append(self.ground_tracker)
        self.ground_tracker.delta_location[2] = -self.wom_target.wheel_info.radius

        # point the target's ground tracker property to the ground tracker
        self.wom_target.target.wom[ws.wom_ground_tracker] = self.ground_tracker


    def create_rotation_tracker(self):
        self.rotation_tracker = self.create_tracker(ws.type_rotation)
        self.all_trackers.append(self.rotation_tracker)

    def create_tracker(self,wom_type,draw=False):
        w = self.wom_target.wheel_info
        s = w.width
        wom_id = self.wom_target.target.wom.wom_id

        points = []
        if draw:
            points = [ (1*s,0,0),(-1*s,0,0),(0,0,0),(0,1*s,0),(0,-1*s,0),(0,0,0),(0,0,1*s),(0,0,-1*s)]

    
        # Create curve data
        curve_data = bpy.data.curves.new('curve', type='CURVE')
        curve_data.dimensions = '3D'

        # Create spline 
        polyline = curve_data.splines.new('POLY')

        # Add points to the spline. Skip this step to make it be an empty curve and never draw
        polyline.points.add(len(points) - 1)
        for i, point in enumerate(points):
            polyline.points[i].co = (point[0], (point[1]), point[2], 1)


        # Create the curve from all the data
        curve_obj = bpy.data.objects.new('curve_obj', curve_data)
        bpy.context.collection.objects.link(curve_obj)
        tracker = curve_obj

        # assign name, wom id, and wom type
        tracker.name = self.wom_target.target.name + '.' + wom_type
        setattr(tracker.wom,ws.wom_id,wom_id)
        setattr(tracker.wom,ws.wom_type,wom_type)
        return tracker
    



    def apply_target_logic(self):
        t=self.wom_target.target
        w=self.wom_target.wheel_info
        gt = self.ground_tracker

        # scripted rotation driver for tracking movement and applying rotation

        fcurve = t.driver_add(ws.wom_auto_rotation)
        driver = fcurve.driver
        driver.use_self = True
        driver.expression = 'wheel_logic(self,matrix_world)'
        var = driver.variables.new()
        var.type = 'SINGLE_PROP'
        var.name = 'matrix_world'
        targets = var.targets
        targets[0].id = gt
        targets[0].data_path = 'matrix_world'


        # Set auto rotation after the driver goes through once
        scene = bpy.context.scene.name
        current_frame = bpy.data.scenes[scene].frame_current
        bpy.data.scenes[scene].frame_set(current_frame)
        t[ws.wom_auto_rotation] = 0.0

        # Set the other property defaults
        # forward axis
        setattr(t.wom,ws.wom_forward_axis,w.forward)

        # radius
        setattr(t,ws.wom_radius,w.radius)

        # rotation power
        setattr(t,ws.wom_rotation_power,1.0)


    def apply_rotation_tracker_logic(self):
        axis = self.wom_target.rotation_axis
        self.connection_utils.drive_tracker_rotation(self.wom_target.target,self.rotation_tracker,axis,self.wom_target.armature)


    def set_tracker_hierarchy(self):
        parent_utils = ParentUtils()
        parent_utils.parent_default(self.ground_tracker,self.axis_tracker)
        parent_utils.parent_default(self.rotation_tracker,self.axis_tracker)

    def set_tracker_locations(self):

        #### root tracker and its children to wheel
        
        # for bone setups
        if self.wom_target.armature:
            wheel = self.wom_target.wheel_info.wheel_object
            bone = self.wom_target.target
            armature = self.wom_target.armature

            # see if the wheel is skinned
            is_skinned = False
            for modifier in wheel.modifiers:
                if modifier.type == 'ARMATURE':
                    if modifier.object == armature:
                        is_skinned = True

            if is_skinned:
                animated_wheel_matrix = self.wom_utils.get_armature_deformed_wheel_global_matrix(wheel,bone,armature)
                self.axis_tracker.location = animated_wheel_matrix.translation

            # otherwise it's probably just parented to the bone, so use its world position
            else:
                self.axis_tracker.location = wheel.matrix_world.translation



        # for mesh setups
        else:
            self.axis_tracker.location = self.wom_target.wheel_info.location

        ##### helper
        # self.helper_tracker.location = self.axis_tracker.location
        # self.helper_tracker.location[2] = self.helper_tracker.location[2] - self.wom_target.wheel_info.radius
        # self.connection_utils.constraint_child_of(self.helper_tracker,self.ground_tracker)

    def lock_tracker(self,tracker,lock_transforms=True, unselectable=True,hide=True):
        if self.lock:
            if lock_transforms:
                axes = [0,1,2]
                types = ['lock_location','lock_rotation','lock_scale']
                for type in types:
                    for axis in axes:
                        getattr(tracker, type)[axis] = True
            if unselectable:
                tracker.hide_select = True
            if hide:
                tracker.hide_viewport = True ### this is for the monitor icon. hides across all view layers
                # tracker.hide_render = True ### this is for the render. No need since they are curves
                # tracker.hide_set(True) ### this is for the eye icon

    def move_trackers_to_collections(self):
        # self.collections.move_to_collection(self.all_trackers,self.wom_target.collection,True)
        self.collections.move_to_collection(self.all_trackers,self.wom_target.collection,True)


    def lock_everything(self):
        # lock all the trackers and the data collection after everything is in place
        if self.lock:

            # trackers
            self.lock_tracker(self.axis_tracker)
            self.lock_tracker(self.ground_tracker)
            self.lock_tracker(self.rotation_tracker)
            # self.lock_tracker(self.helper_tracker,hide=True)

            # data collection
            # self.collection_utils.lock_data_collection(True)


class WheelGeoInfo():
    def __init__(self,wheel,forward):
        self.wheel_object = wheel
        self.name = wheel.name
        self.parent = wheel.parent
        self.forward = None
        self.rotation_axis = None
        self.global_rotation_axis = None
        self.invert_rotation = False
        self.width = None
        self.length = None
        self.location = None
        self.radius = None
        self.bounds_ws = None
        self.dimensions_ws = None
        self.matrix_world = None

        self.wom_utils = WomUtils()
        self.get_wheel_geo_data(wheel,forward)
        


    def get_wheel_geo_data(self,wheel,forward):
            
            # get world matrix and world space dimensions
            self.matrix_world = wheel.matrix_world
            self.location = self.matrix_world.translation
            bounds_ls = wheel.bound_box
            self.bounds_ws = [self.matrix_world @ mathutils.Vector(corner) for corner in bounds_ls]

            # get radius and world space dimensions
            self.dimensions_ws = self.wom_utils.get_dimensions_from_bounds(self.bounds_ws)
            lowest_point = self.wom_utils.get_wheel_bottom(wheel)
            self.radius = abs(lowest_point - self.location[2])

                
            if forward == 'auto':
                # get data about local rotation axis, global forward axis, and rotation inversion
                self.global_rotation_axis = self.wom_utils.get_world_rotation_axis(self.dimensions_ws, self.wheel_object)
                self.forward = 'x'
                if self.global_rotation_axis == 0:
                    self.forward = 'y'

            if forward == 'x':
                self.forward = 'x'
                self.global_rotation_axis = 1
            if forward == 'y':
                self.forward = 'y'
                self.global_rotation_axis = 0

            

            # get local rotation axis and invert info 
            self.rotation_axis, self.invert_rotation = self.wom_utils.get_local_rotation_axis_mesh(self.matrix_world,self.global_rotation_axis)

            # width/length data. Used for creating trackers and fake parent objects
            if self.forward == 'x':
                self.width = self.dimensions_ws[1]
                self.length = self.dimensions_ws[0]
            else:
                self.width = self.dimensions_ws[0]
                self.length = self.dimensions_ws[1]


class WomTargetData():
    def __init__(self,wheel_info,target,rotation_axis,matrix_world,collection,wom_id,armature=None):
        self.wheel_info = wheel_info
        self.wom_id = wom_id
        self.target = target
        self.rotation_axis = rotation_axis
        self.world_location = matrix_world.translation
        self.armature = armature
        self.matrix_world = matrix_world
        self.collection = collection


class ConnectionUtils():
    
    def __init__(self):
        pass


    def constraint_final_rotation(self,item,driver,rotation_axis,is_bone=False):  
        """Create rotation constraint that drives a wheel mesh or wheel bone"""
        # create copy rotation constraint and set settings
        constraint_name = 'Wheel-O-Matic Rotation Constraint'

        if type(rotation_axis) == int:
            axis_dict = {0:'x',1:'y',2:'z'}   
            rotation_axis = axis_dict[rotation_axis]

        constraint = item.constraints.new("COPY_ROTATION")
        constraint.name = constraint_name
        constraint.target = driver
        constraint.mix_mode = 'AFTER'
        ignore_axes = ['x','y','z']
        ignore_axes.remove(rotation_axis)
        for axis in ignore_axes: setattr(constraint, f'use_{axis}', False) 
        constraint.target_space = 'LOCAL'
        constraint.owner_space = 'LOCAL'

        return constraint


    def drive_tracker_rotation(self,source_obj,target_obj,axis,armature=None):
        """Create driver to drive rotation tracker's rotation from rotation data """
        
        if type(axis) == str:
            axis_dict = {'x':0,'y':1,'z':2}
            axis = axis_dict[axis]

        # create driver
        fcurve = target_obj.driver_add('delta_rotation_euler', axis)
        driver = fcurve.driver
        driver.expression = 'wom_auto_rotation'
        var = driver.variables.new()
        var.type = 'SINGLE_PROP'
        var.name = 'wom_auto_rotation'
        targets = var.targets
        targets[0].transform_space = 'WORLD_SPACE'

        if armature:
            targets[0].id = armature
            targets[0].data_path = f'pose.bones["{source_obj.name}"].{ws.wom_auto_rotation}'
        else:
            targets[0].id = source_obj
            targets[0].data_path = f'{ws.wom_auto_rotation}'
            # targets[0].data_path = ws.wom_auto_rotation


    def constraint_child_of(self,child,parent,name = None):
        constraint = child.constraints.new("CHILD_OF")
        constraint.target = parent
        if name:
            constraint.name = name


    def constraint_child_of_bone(self,tracker,armature,bone,name=None):
        constraint = tracker.constraints.new("CHILD_OF")
        constraint.target = armature
        if bone:
            constraint.subtarget = bone.name
        if name:
            constraint.name = name

    def lwh_from_bounds(self,bounds):
        x_vals = []
        y_vals = []
        z_vals = []
        for bound in bounds:
            x_vals.append(bound[0])
            y_vals.append(bound[1])
            z_vals.append(bound[2])
        x_width = max(x_vals) - min(x_vals)
        y_width = max(y_vals) - min(y_vals)
        z_width = max(z_vals) - min(z_vals)

        return [x_width,y_width,z_width]


class Collections():

    def __init__(self):
        pass
        

    def get_main_collection(self):
        main_collection = None
        for collection in bpy.data.collections:
            if bpy.context.scene.user_of_id(collection):
                if collection.get(ws.wom_id):
                    if collection.get(ws.wom_id) == ws.wom_collection_main_id:
                        main_collection = collection
                        break
                    
        if not main_collection:
            main_collection = self.create_collection(ws.wom_collection_main_name,ws.wom_collection_main_id,True)
        return main_collection


    def create_collection(self,collection_name,wom_target_id,is_main=False):

        collection = bpy.data.collections.new(collection_name)

        # if no id provided, it's the main collection
        if is_main:
            bpy.context.scene.collection.children.link(collection)
            wom_target_id = ws.wom_collection_main_id
            collection_type = ws.type_main_collection
        
        # otherwise its a wheel specific collection. 
        else:
            # get main collection
            main_collection = self.get_main_collection()

            # link to it
            main_collection.children.link(collection)

            # assign id and id type
            wom_target_id = wom_target_id
            collection_type = ws.type_collection

        # set the wom id and type
        setattr(bpy.types.Collection,ws.wom_id,bpy.props.StringProperty(get=get_wom_id))
        setattr(bpy.types.Collection,ws.wom_type,bpy.props.StringProperty(get=get_wom_type))
        collection[ws.wom_id] = wom_target_id
        collection[ws.wom_type] = collection_type

        return collection
    

    def get_collection_by_id(self,wom_id_to_match):
        matching_collection = None
        for collection in bpy.data.collections:
            if bpy.context.scene.user_of_id(collection):
                wom_collection_id = collection.get(ws.wom_id)
                if wom_collection_id:
                    if wom_id_to_match in wom_collection_id:
                        matching_collection = collection
                        break
        return matching_collection
    
    def get_wom_objects_in_collection(self,collection):
        wom_objects = []
        for item in collection.all_objects:
            if item.wom.get(ws.wom_id):
                wom_objects.append(item)

        return wom_objects

    def move_to_collection(self,items,destination_collection,hide_after_link=False):
        # note, this removes the item from ANY collection it may be in, and puts it in the new collection
        if not type(items) == list:
            items = [items]
        
        for item in items:
            #unlink current collections
            for col in list(item.users_collection):
                col.objects.unlink(item)
           
                # link to new collection
                if not destination_collection in item.users_collection:
                    destination_collection.objects.link(item)
                if hide_after_link:
                    item.hide_set(True)

    def move_non_wom_object_out_of_wom_collection(self,item,wom_collection):
        if wom_collection and item:
            scene_collection = bpy.context.scene.collection
            for col in list(item.users_collection):
                if col == wom_collection:
                    col.objects.unlink(item)

            if not scene_collection in item.users_collection:
                scene_collection.objects.link(item)

    def remove_collection(self,wom_collection):

        # move anything in the collection
        if wom_collection:
            self.clear_collection(wom_collection)
            # for obj in wom_collection.all_objects:   
            #     collections.move_non_wom_object_out_of_wom_collection(obj,wom_collection)
            # delete the collection
            bpy.data.collections.remove(wom_collection, do_unlink=True)

    def clear_collection(self,wom_collection):
        scene_collection = bpy.context.scene.collection
        wom_collection_objects = wom_collection.all_objects
        if wom_collection_objects:
            for item in set(wom_collection_objects):
                wom_collection.objects.unlink(item)
                # for col in list(item.users_collection):
                #     if col == wom_collection:
                #         col.objects.unlink(item)

                if not scene_collection in item.users_collection:
                    scene_collection.objects.link(item)
            


    # def force_show_collection(self,collection):

    #     # 
    #     top_layer_collection = bpy.context.view_layer.layer_collection
    #     layer_collections = []
    #     for lc in self.__walk_layer_collections(top_layer_collection):
    #         layer_collections.append(lc)

    #     for layer in layer_collections:
    #         if layer.name == collection.name:
    #             collection.hide_viewport = False


    # def __walk_layer_collections(self,lc):
    #     yield lc
    #     for child in lc.children:
    #         yield from self.__walk_layer_collections(child)


class ParentUtils():
    def __init__(self):
        pass

    def parent_default(self,child,parent):
        """Default Blender parenting type"""
        child.parent = parent
        child.matrix_parent_inverse = parent.matrix_world.inverted()

    def parent_no_inverse_keep_transform(self,child,parent):
        """Blender parenting type where zeroed transforms means it matches parent exactly"""
        bpy.ops.object.select_all(action='DESELECT')
        bpy.data.objects[child.name].select_set(True)
        bpy.data.objects[parent.name].select_set(True)
        bpy.context.view_layer.objects.active = parent
        bpy.ops.object.parent_no_inverse_set(keep_transform=True)

    def create_auto_parent_geo(self,wheel_info,wom_id):
        w = wheel_info
        aol = arrow_outer_length = 1.3 * (w.length/2)
        aow = arrow_outer_width = 1.1 * (w.width)
        aiw = arrow_inner_width = 0.7 * (w.width)
        ail = arrow_inner_length = 0.4 * (w.length/2)

        points = [
                    (aol,0,0),(ail,-aow,0),(ail,-aiw,0),(-ail,-aiw,0),(-ail,-aow,0),(-aol,0,0),
                    (-ail,aow,0),(-ail,aiw,0),(ail,aiw,0),(ail,aow,0),(aol,0,0)
                ]

        # Create curve data
        curve_data = bpy.data.curves.new('curve', type='CURVE')
        curve_data.dimensions = '3D'

        # Create spline 
        polyline = curve_data.splines.new('POLY')

        # Add points to the spline
        polyline.points.add(len(points) - 1)
        for i, point in enumerate(points):
            if w.forward == 'x':
                polyline.points[i].co = (point[0], (point[1]), point[2], 1)
            else:
                polyline.points[i].co = (point[1], point[0], point[2], 1)

        # Create the curve from all the data
        curve_obj = bpy.data.objects.new('curve_obj', curve_data)
        bpy.context.collection.objects.link(curve_obj)

        curve_obj.location = w.location[0],w.location[1],w.location[2] - w.radius

        # set name, wom_id, and type
        curve_obj.name = f'{w.name}.{ws.type_auto_parent}'
        curve_obj.wom[ws.wom_id] =  wom_id
        curve_obj.wom[ws.wom_type] = ws.type_auto_parent


        

        return curve_obj


class WomUtils():

    def __init__(self):
        pass

    #### Wheel mesh object utils #####
    def get_world_rotation_axis(self,dimensions_ws,wheel_object,ignore_z = True):
        # the two similar length world bounds are the non rotation axes (think wheel length and height) We want the outlier (wheel width)
        dims = dimensions_ws
        yz = abs(dims[1] - dims[2])
        xz = abs(dims[0] - dims[2])
        xy = abs(dims[0] - dims[1])
        # outlier axis will be the one with the lowest number. This is the global rotation axis
        values_lookup = [yz,xz,xy]
        if ignore_z:
            values_lookup.pop()
        outlier = values_lookup.index(min(values_lookup))

        # handle default cylinder edge case. it's 1 unit in all directions, so need to figure out axis from mesh
        x_y_difference = abs(dimensions_ws[0] - dimensions_ws[1])
        
        if x_y_difference < 0.000001:
            x = mathutils.Vector((1.0,0.0,0.0))
            y = mathutils.Vector((0.0,1.0,0.0))

            more_than_4_verts = []
            polys = wheel_object.data.polygons
            matrix_ws = wheel_object.matrix_world
            matrix_ws_rot = matrix_ws.to_3x3().normalized()
            for poly in polys:
                vertices = poly.vertices
                if len(vertices) > 4:
                    more_than_4_verts.append(poly)

            if len(more_than_4_verts) == 2:
                # probably the default cylinder cuz 2 faces with extra verts (cylinder caps), dot x on one of those polys to find rotation axis
                poly_normal_ws = matrix_ws_rot @ more_than_4_verts[0].normal
                dot_x = abs(x.dot(poly_normal_ws))
                if dot_x >0.5:
                    outlier = 0
                else:
                    outlier = 1

        return outlier

    def get_dimensions_from_bounds(self,bounds):
        x_vals = []
        y_vals = []
        z_vals = []
        for bound in bounds:
            x_vals.append(bound[0])
            y_vals.append(bound[1])
            z_vals.append(bound[2])
        x_width = max(x_vals) - min(x_vals)
        y_width = max(y_vals) - min(y_vals)
        z_width = max(z_vals) - min(z_vals)

        dimensions = [x_width,y_width,z_width]
        return dimensions

    def get_local_rotation_axis_mesh(self,matrix_world,global_rotation_axis):
        
        """
            compare global rotation axis against the axis vectors of the object's matrix to find
            the local rotation axis. The one with the highest absolute value of the dot product is the matching axis. 
            If the dot product is negative, the rotation constraint needs to be inverted. 
        """

        if global_rotation_axis == 0:
            world_rotation_vector = mathutils.Vector((1.0,0.0,0.0))
        else:
            world_rotation_vector = mathutils.Vector((0.0,1.0,0.0))

        # get the normalized world orientation matrix of the object
        # also transpose the matrix because its column based for some reason
        mtx_world_orientation_normalized = matrix_world.to_3x3().normalized().transposed()

        # use that and the world rotation vector to find out what axis to spin the wheel on
        local_rotation_axis, invert_rotation = self.__local_axis_and_inversion(mtx_world_orientation_normalized,world_rotation_vector)
        return local_rotation_axis, invert_rotation

    def get_wheel_bottom(self,obj):
        world_verts = [obj.matrix_world @ vertex.co for vertex in obj.data.vertices]
        all_z = []
        for v in world_verts:
            all_z.append(v[2])
        return (min(all_z))


    #### Wheel bone object utils ####
    def get_armature_deformed_wheel_global_matrix(self,wheel,bone,armature):
        wheel_mw = wheel.matrix_world
        bone_mw = bone.id_data.matrix_world @ bone.matrix
        bone_ml = bone.id_data.matrix_world @ armature.data.bones[bone.name].matrix_local


        matrix = bone_mw @ bone_ml.inverted() @ wheel_mw

        # print(f'##### wheel world #####\n{wheel_mw}')
        # print(f'##### bone world #####\n{bone_mw}')
        # print(f'##### bone local #####\n{bone_ml}')
        # print(f'##### output_matrix #####\n{matrix}')
        # print('###########################################')
        
        
        return matrix

    def get_local_rotation_axis_bone(self,wheel_info,bone,armature):

        """
            compare global rotation axis against the world axis vectors of the bone to find
            the local rotation axis (armature orientation is also taken into account)
            The one with the highest absolute value of the dot product is the matching axis. 
            If the dot product is negative, the rotation constraint needs to be inverted. 
 
        """
        local_rotation_axis = None
        invert_rotation = False


        if wheel_info.global_rotation_axis == 0:
            world_rotation_vector = mathutils.Vector((1.0,0.0,0.0))
        else:
            world_rotation_vector = mathutils.Vector((0.0,1.0,0.0))

        # get armature relative world axes
        x = bone.x_axis
        y = bone.y_axis
        z = bone.z_axis


        axis_vectors = [x,y,z]

        # get the normalized world orientation of the armature
        mtx_world_orientation_normalized = armature.matrix_world.to_3x3().normalized()

        # multiply the axis vectors by the armature's normalized world rotation to get what directions they point in world space
        axis_vectors_ws = [mtx_world_orientation_normalized @ mathutils.Vector(axis) for axis in axis_vectors]
        local_rotation_axis, invert_rotation = self.__local_axis_and_inversion(axis_vectors_ws,world_rotation_vector)

        return local_rotation_axis, invert_rotation
    
    def __local_axis_and_inversion(self,axis_vectors,world_rotation_vector):
        invert_rotation = False
        local_rotation_axis = None
        dot_results = []
        abs_dot_results = []
        for vector in axis_vectors:
            dot = vector.dot(world_rotation_vector)
            dot_results.append(dot)
            abs_dot_results.append(abs(dot))

        axis_index = abs_dot_results.index(max(abs_dot_results))
        actual_value = dot_results[axis_index]
        lookup_dict = {0:'x',1:'y',2:'z'}
        local_rotation_axis = lookup_dict[axis_index]
        if actual_value < 0:
            invert_rotation = True

        return local_rotation_axis, invert_rotation


    #### utils for all ####
    def set_wom_id(self,obj,is_bone = False):
        obj_name = obj.name
        obj_id = id(obj)
        wom_id = f'wom_{obj_id}_{obj_name}'

        setattr(obj.wom,ws.wom_id,wom_id)
        setattr(obj.wom,ws.wom_driven,True)
        obj.wom[ws.wom_type] = ws.type_target
        return wom_id
    
    def get_wom_id(self,item):
        if item:
            if item.type == 'MESH':
                sel_id =  item.wom.get(ws.wom_id)
                if sel_id:
                    return sel_id

            elif item.type == 'ARMATURE':
                bone = bpy.context.active_pose_bone
                if bone:
                    bone_id =  bone.wom.get(ws.wom_id)
                    if bone_id:
                        return bone_id

            else:
                return None

    def get_wom_ids_from_selection(self):

        # returns a list of valid wom ids
        wom_ids = []
        selected = bpy.context.selected_objects
        for sel in selected:
            wom_id = self.get_wom_id(sel)
            if wom_id:
                wom_ids.append(wom_id)
        return wom_ids
    
    def get_wom_id_for_active_object_or_pose_bone(self):
        wom_id = None
        active = bpy.context.active_object
        if active:
            wom_id = self.get_wom_id(active)
        return wom_id
    
    def is_wom_driven(self,item):
        if item:
            if item.type == 'MESH':
                if item.wom:
                    wom_type = item.wom.get(ws.wom_type)
                    if wom_type == ws.type_target:
                        return True

            elif item.type == 'ARMATURE':
                bone = bpy.context.active_pose_bone
                if bone:
                    if bone.wom:
                        wom_type = bone.wom.get(ws.wom_type)
                        if wom_type == ws.type_target:
                            return True
            else:
                return False

    def get_wom_tracker(self,tracker_type):
        tracker = None
        wom_id = self.get_wom_id_for_active_object_or_pose_bone()
        if wom_id:
            tracker_lookup = self.get_connected_wom_controller_of_type(wom_id,tracker_type)
            if tracker_lookup:
                tracker = tracker_lookup
        return tracker
    
    def get_connected_wom_controller_of_type(self,wom_id,tracker_type):
        """wom_id is the wom id of the driven wheel or bone. Tracker type is the type of wom tracker object (axis,ground,rotation)"""
        collection_utils = Collections()
        wom_collection = collection_utils.get_collection_by_id(wom_id)
        all_wom_objects = collection_utils.get_wom_objects_in_collection(wom_collection)
        for wom_object in all_wom_objects:
            wom_obj_id = wom_object.wom.get(ws.wom_id)
            if wom_obj_id:
                if wom_id in wom_obj_id:

                    if tracker_type in wom_obj_id:
                        return wom_object
        return None

    def get_scene_wom_objects(self):

        scene_wom_objects = []
        all_objects = bpy.context.scene.objects
        for obj in all_objects:
            if obj.type == 'MESH' or obj.type == 'CURVE':
                if obj.wom:
                    wom_id = obj.wom.get(ws.wom_id)
                    if wom_id:
                        scene_wom_objects.append(obj)

            if obj.type == 'ARMATURE':
                bones = obj.pose.bones
                for bone in bones:
                    if bone.wom:
                        wom_id = bone.wom.get(ws.wom_id)
                        if wom_id:
                            scene_wom_objects.append(bone)

        return list(set(scene_wom_objects))

    def remove_stray_wom_data_from_scene(self):
        # bpy.ops.object.select_all(action='DESELECT')
        # active = bpy.scene.active_object
        # active.select_set(False)
        all_scene_wom_objects = self.get_scene_wom_objects()
        wom_bundles_by_id = {}
        for obj in all_scene_wom_objects:
            wom_id = obj.wom[ws.wom_id]
            if wom_id:
                if not wom_id in wom_bundles_by_id:
                    wom_bundle = WomBundle(wom_id)
                    wom_bundles_by_id[wom_id] = wom_bundle
                wom_bundle = wom_bundles_by_id[wom_id]
                # if this is the target object
                wom_type = obj.wom.get(ws.wom_type)
                if wom_type == ws.type_target:
                        wom_bundle.target = obj
                else:
                    wom_bundle.other_data.append(obj)


        for wom_id in wom_bundles_by_id:
            
            bundle = wom_bundles_by_id[wom_id]
            for i in bundle.other_data:
                print(i)
            
            if bundle.target == None:
                # remove the items from the scene
                for item in bundle.other_data:
                    bpy.data.objects.remove(item, do_unlink=True)
                
                # remove the collection if it exists
                col = collections.get_collection_by_id(bundle.wom_id)
                if col:
                    collections.remove_collection(col)

        # clean up any stray auto rotation drivers on any armatures
        all_objects = bpy.context.scene.objects
        for item in all_objects:
            if item.type == 'ARMATURE':
                
                armature = item
                drivers = armature.animation_data.drivers
                for driver in drivers: 
                    if 'wheel_logic' in driver.driver.expression:
                        data_path = driver.data_path
                        driven_bone_name = data_path.split('"')[1]
                        if not driven_bone_name in armature.pose.bones:
                            # bone target no longer exists, delete the driver
                            armature.driver_remove(driver.data_path, -1)

    def link_wheel_logic(self):
        all_scene_wom_objects = self.get_scene_wom_objects()
        wo = WheelOperators()
        wo.create_global_wheel_logic()






class WomBundle():
    """Bundle of all wom data related to this wom id. Used for removing wom data"""
    def __init__(self,wom_id):
        self.wom_id = wom_id
        self.target = None
        self.other_data = []

# TODO change logic so these aren't out in the breeze like this
wu = WomUtils()
collections = Collections()
# wo = WheelOperators()

# Helper fuction to create global wheel logic in a new file. called in __init__.py
def generate_global_wheel_logic():
    print('initializing Wheel-O-Matic...')
    wheel_operators = WheelOperators()
    wheel_operators.create_global_wheel_logic()
    print('Wheel-O-Matic initialized.')



# Operator classes to register. Registration happens in __init__.py
operators = [OBJECT_OT_wom_setup_mesh,OBJECT_OT_wom_setup_bone,OBJECT_OT_wom_clear_rotation,OBJECT_OT_wom_remove_automation,OBJECT_OT_wom_remove_stray_data,Wheel_Object_Properties]