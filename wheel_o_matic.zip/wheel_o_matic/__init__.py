"""
Wheel-O-Matic
Author: TechArtToolBox
Date: 2025
Version: 1.0
Blender addon/extention for automating wheels
"""


# add on meta data 

# BLENDER_VERSION = bpy.app.version

# if BLENDER_VERSION < (4,2,0):
bl_info = {
    'name' : 'Wheel-O-Matic',
    'author' : 'Tech Art Tool Box',
    'version' : (1,0,0),
    'blender' : (3,0,0),
    'location' : '3D Viewport sidebar, under the item tab. There will be  a panel called Wheel-O-Matic',
    'description' : 'Utility for automatic wheel rotation',
    'doc_url': 'https://www.youtube.com/@techarttoolbox',
    'category' : 'Development'
    }


import bpy
from bpy.app.handlers import persistent

from wheel_o_matic import wheel_utilities
from wheel_o_matic import wheel_ui



def register():

    #### Register UI classes
    for ui_element in wheel_ui.ui_elements:
        bpy.utils.register_class(ui_element)
        
    #### Register UI property group
    bpy.types.Scene.wheel_o_matic = bpy.props.PointerProperty(type=wheel_ui.Wheel_UI_Properties)

    #### Operators
    for operator in wheel_utilities.operators:
        bpy.utils.register_class(operator)

    #### Object PropertyGroup 
    bpy.types.Object.wom = bpy.props.PointerProperty(type=wheel_utilities.Wheel_Object_Properties)
    
    #### Pose Bones PropertyGroup 
    bpy.types.PoseBone.wom = bpy.props.PointerProperty(type=wheel_utilities.Wheel_Object_Properties)

    #### User facing properties 
    wheel_utilities.register_user_facing_properties()

    #### Global wheel logic. Need this initialized per scene to handle linking/appending scenes with Wheel-O-Matic data
    bpy.app.handlers.load_post.append(custom_load_handling)



def unregister():
    for cls in reversed(wheel_ui.ui_elements):
        bpy.utils.unregister_class(cls)
        
    del bpy.types.Scene.wheel_o_matic

    for cls in reversed(wheel_utilities.operators):
        bpy.utils.unregister_class(cls)

    del bpy.types.Object.wom
    del bpy.types.PoseBone.wom

    bpy.app.handlers.load_post.append(custom_load_handling)


@persistent
def custom_load_handling(scene):
    wheel_utilities.generate_global_wheel_logic()


if __name__ == "__main__":
    register()