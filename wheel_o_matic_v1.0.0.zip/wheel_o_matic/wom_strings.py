# for the wom propertygroup

wom_id                      = 'wom_id'
wom_type                    = 'wom_type'
wom_defined_parent          = 'wom_defined_parent'
wom_driven                  = 'wom_driven'
wom_driven_armature         = 'wom_driven_armature'
wom_forward_axis            = 'forward_axis'
wom_position_old            = 'position_old'
wom_axis_offset             = 'wom_axis_offset'


# for regular properties
wom_radius                  = 'wom_radius' 
wom_rotation_power          = 'wom_auto_rotation_power' 
wom_auto_rotation           = 'wom_auto_rotation'
wom_id_ui                   = 'wom_id_ui'


#### types of wom objects
type_target                 = 'target'
type_rotator                = 'wom_rotator'
type_auto_parent            = 'auto_parent'

### driver_namespace key
dns_key                     = 'wom_locators'


#### UI hint strings
desc_apply_trasforms    =   'Apply rotation and scale of the wheel geo to clean the transforms before setup'
desc_auto_rot           =   'Auto rotation of the wheel (in radians). DO NOT EDIT! Will break the wheel logic' 
desc_auto_rot_power     =   'Strength of the auto rotation. 1 is default. 0 is no rotation. Negative values reverse rotation. Type in values to go beyond the limits'
desc_locator_scale      =   'Global scale for all of the wheel locators'
desc_override_defaults  =   'Override the default settings for automation'
desc_radius             =   'Radius of the wheel, adjust as needed. Use \'Toggle Locators\' in the Utilities section to visualize'
desc_show_tracker       =   'Show the wheel tracker. Usefull for visualizing radius and debuging wheels that act strange'
desc_wheel_obj          =   'Geo of the wheel. Select the outermost geo (like the tire) if wheel is in multiple pieces'

#### UI names
name_radius             =   'Radius'
name_auto_rot_power     =   'Rotation Power'
name_show_tracker       =   'Show Tracker'
name_auto_rotation      =   'Auto Rotation'

#### logging/printing/warning
automate_success        =   'Wheel-O-Matic automation complete!'
automate_fail           =   'Wheel-O-Matic was unable to complete the automation. Please make sure your selection is correct.'
invoke_warn             =   'Please use the Wheel-O-Matic UI for setting up automated wheels/bones. Cancelling.'
locator_remove_warn     =   'Unable to remove existing Wheel-O-Matic locator draw handler. Restarting Blender should fix that.'