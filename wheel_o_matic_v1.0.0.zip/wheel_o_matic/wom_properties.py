import bpy
from . import wom_strings as ws

#### UI Property Group
class WOM_UI_Properties(bpy.types.PropertyGroup):
    
    # filtered poll result for when picking mesh for bone setup
    def valid_wheel_object(self,object):
        """ limit dropdown to current scene, and limit to mesh objects"""
        for scene in object.users_scene:
            if scene.name == bpy.context.scene.name:
                if object.type == 'MESH':
                    return object

    # UI forward facing properties
    b_apply_trasforms       :   bpy.props.BoolProperty (name = 'Clean Geo Transforms', default=False, description = ws.desc_apply_trasforms)
    f_locator_scale         :   bpy.props.FloatProperty (name = 'Scale Locators', default=1.0,min=0.01,description = ws.desc_locator_scale)
    p_wheel_obj             :   bpy.props.PointerProperty(name = '', type=bpy.types.Object,poll=valid_wheel_object, description = ws.desc_wheel_obj)
    world_forward_axis      :   bpy.props.EnumProperty(
                                    name= '',
                                    description = "World forward axis of the wheel",
                                    items=  [('auto','Auto','Automatically detect forward axis (default)','',0),
                                            ('x','X','Wheel rolls forward on the world X axis','',1),
                                            ('y','Y','Wheel rolls forward  on the world Y axis','',2)],
                                    default = 'auto'
                                )
    
    # UI internal properties
    b_draw_locators         :   bpy.props.BoolProperty (default=False)



#### WOM object property group
class WOM_Object_Properties(bpy.types.PropertyGroup):

    # internal for wheel logic
    forward_axis            :   bpy.props.StringProperty()
    position_old            :   bpy.props.FloatVectorProperty()
    wom_id                  :   bpy.props.StringProperty()
    wom_driven              :   bpy.props.BoolProperty()
    wom_driven_armature     :   bpy.props.BoolProperty()
    wom_type                :   bpy.props.StringProperty()
    wom_defined_parent      :   bpy.props.PointerProperty(type=bpy.types.Object)
    wom_axis_offset         :   bpy.props.FloatVectorProperty(size=16, subtype='MATRIX', default = [1,0,0,0,
                                                                                                    0,1,0,0,
                                                                                                    0,0,1,0,
                                                                                                    0,0,0,1])


#### classes to temporarily store WOM objects on the scene
class WOM_Reference(bpy.types.PropertyGroup):
    wom_object  :   bpy.props.PointerProperty(type=bpy.types.Object)

class WOM_Scene_References(bpy.types.PropertyGroup):
    wom_reference_collection : bpy.props.CollectionProperty(type=WOM_Reference)


#### User facing properties
def register_user_facing_properties():

    # wom auto rotation
    setattr(bpy.types.Object,ws.wom_auto_rotation,bpy.props.FloatProperty(name=ws.name_auto_rotation,default = 0.0,description=ws.desc_auto_rot))
    setattr(bpy.types.PoseBone,ws.wom_auto_rotation,bpy.props.FloatProperty(name=ws.name_auto_rotation,default = 0.0,description=ws.desc_auto_rot))

    # wom auto rotation power
    setattr(bpy.types.Object,ws.wom_rotation_power,bpy.props.FloatProperty(name=ws.name_auto_rot_power,default = 1,soft_min=-5,soft_max=5,description=ws.desc_auto_rot_power))
    setattr(bpy.types.PoseBone,ws.wom_rotation_power,bpy.props.FloatProperty(name=ws.name_auto_rot_power,default = 1,soft_min=-5,soft_max=5,description=ws.desc_auto_rot_power))
    
    # wom radius
    setattr(bpy.types.PoseBone,ws.wom_radius,bpy.props.FloatProperty(name=ws.name_radius,min=0.001,default=1,description=ws.desc_radius))
    setattr(bpy.types.Object,ws.wom_radius,bpy.props.FloatProperty(name=ws.name_radius,min=0.001,default=1,description=ws.desc_radius))


classes = [WOM_UI_Properties,WOM_Object_Properties,WOM_Reference,WOM_Scene_References]