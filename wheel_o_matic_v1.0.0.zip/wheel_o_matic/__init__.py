# Legacy Support (BLENDER_VERSION < (4,2,0))
bl_info = {
    'name' : 'Wheel-O-Matic',
    'author' : 'Tech Art Tool Box',
    'version' : (1,0,0),
    'blender' : (3,0,0),
    'location' : '3D Viewport sidebar, there will be a tab called Wheel-O-Matic',
    'description' : 'Automatic wheel rotation. Works with meshes and bones.',
    # 'doc_url': 'https://www.youtube.com/@techarttoolbox',
    'doc_url': 'https://github.com/TechArtToolBox/wheel-o-matic/',
    'category' : 'Animation'
    }

# Blender imports
import bpy
from bpy.app.handlers import persistent


# Wheel O Matic imports
from . import wom_operators
from . import wom_properties
from . import wom_render
from . import wom_ui
from . import wom_utilities
from . import wom_strings as ws


def register():


    #### Register Properties
    for cls in wom_properties.classes:
        bpy.utils.register_class(cls)

    #### Register UI 
    for cls in wom_ui.classes:
        bpy.utils.register_class(cls)

    #### Register Operators
    for cls in wom_operators.classes:
        bpy.utils.register_class(cls)

    #### Register draw logic for locators
    for cls in wom_render.classes:
        bpy.utils.register_class(cls)

    

    
    #### Property groups

    # UI property group
    bpy.types.Scene.wom_ui = bpy.props.PointerProperty(type=wom_properties.WOM_UI_Properties)

    # Object PropertyGroup 
    bpy.types.Object.wom = bpy.props.PointerProperty(type=wom_properties.WOM_Object_Properties)
    
    # Pose Bones PropertyGroup 
    bpy.types.PoseBone.wom = bpy.props.PointerProperty(type=wom_properties.WOM_Object_Properties)

    # Scene WOM objects (referenced by locator logic for drawing locators)
    bpy.types.Scene.wom = bpy.props.PointerProperty(type=wom_properties.WOM_Scene_References)



    #### User facing properties 
    wom_properties.register_user_facing_properties()

    #### Register Wheel-O-Matic global logic. Need this for if the addon was uninstalled, then re-installed with Blender still open.
    bpy.app.driver_namespace['wom_wheel_logic'] = wom_utilities.wom_wheel_logic

    #### Global wheel logic for new scene. Need this initialized per scene to handle linking/appending scenes with Wheel-O-Matic data
    bpy.app.handlers.load_post.append(custom_load_handling)

    print('Wheel-O-Matic installation complete.')




def unregister():

    # Remove locator draw handler
    # bpy.ops.object.wom_remove_locators()

    # Remove the global wheel logic 
    driver_logic = bpy.app.driver_namespace.get('wom_wheel_logic')
    if driver_logic:
        del bpy.app.driver_namespace['wom_wheel_logic']

    # remove locator draw handler if it exists
    locator_draw_handler_key = 'wom_locators'
    locator_draw_logic = bpy.app.driver_namespace.get(locator_draw_handler_key)
    if locator_draw_logic:
        del bpy.app.driver_namespace[locator_draw_handler_key]

    # Unregister
    for cls in reversed(wom_properties.classes):
        bpy.utils.unregister_class(cls)

    for cls in reversed(wom_ui.classes):
        bpy.utils.unregister_class(cls)
        
    for cls in reversed(wom_operators.classes):
        bpy.utils.unregister_class(cls)

    for cls in reversed(wom_render.classes):
        bpy.utils.unregister_class(cls)

    # Delete wom property groups
    del bpy.types.Object.wom
    del bpy.types.PoseBone.wom
    del bpy.types.Scene.wom
    del bpy.types.Scene.wom_ui

    print('Wheel-O-Matic removal complete.')





@persistent
def custom_load_handling(scene):
    bpy.app.driver_namespace['wom_wheel_logic'] = wom_utilities.wom_wheel_logic


if __name__ == "__main__":
    register()